REPLACE INTO ?:banner_descriptions (`banner_id`, `banner`, `url`, `description`, `lang_code`) VALUES(7, 'Подарочный сертификат', 'gift_certificates.add', '', 'ru');
REPLACE INTO ?:banner_descriptions (`banner_id`, `banner`, `url`, `description`, `lang_code`) VALUES(8, 'Выбираем праздничный подарок', 'gift_certificates.add', '', 'ru');

REPLACE INTO ?:banner_descriptions (`banner_id`, `banner`, `url`, `description`, `lang_code`) VALUES(16, 'Финальная распродажа', 'index.php?dispatch=products.final_sale', '', 'ru');
REPLACE INTO ?:banner_descriptions (`banner_id`, `banner`, `url`, `description`, `lang_code`) VALUES(17, 'X-Box', 'index.php?dispatch=products.view&product_id=248', '', 'ru');
REPLACE INTO ?:banner_descriptions (`banner_id`, `banner`, `url`, `description`, `lang_code`) VALUES(18, 'Бонусные баллы', 'index.php?dispatch=pages.view&page_id=23', '', 'ru');
REPLACE INTO ?:banner_descriptions (`banner_id`, `banner`, `url`, `description`, `lang_code`) VALUES(19, 'Подарочные сертификаты', 'index.php?dispatch=pages.view&page_id=19', '', 'ru');
REPLACE INTO ?:banner_descriptions (`banner_id`, `banner`, `url`, `description`, `lang_code`) VALUES(6, 'Бесплатная доставка', 'index.php?dispatch=pages.view&page_id=22', '', 'ru');
REPLACE INTO ?:banner_descriptions (`banner_id`, `banner`, `url`, `description`, `lang_code`) VALUES(9, 'Скидка при выборе пункта самовывоза', 'index.php?dispatch=pages.view&page_id=20', '', 'ru');
