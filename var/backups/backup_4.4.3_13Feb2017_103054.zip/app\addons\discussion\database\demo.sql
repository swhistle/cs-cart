
TRUNCATE TABLE ?:discussion;
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('1', '228', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('2', '242', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('3', '78', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('4', '16', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('5', '170', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('7', '1', 'A', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('8', '2', 'A', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('9', '3', 'A', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('11', '167', 'C', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('16', '243', 'P', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('17', '224', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('18', '5', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('19', '1', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('20', '23', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('21', '8', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('22', '172', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('23', '238', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('24', '167', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('25', '239', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('26', '0', 'E', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('27', '4', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('28', '6', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('29', '7', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('30', '9', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('31', '10', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('32', '11', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('33', '12', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('34', '13', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('35', '14', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('36', '15', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('37', '17', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('38', '18', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('39', '19', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('40', '20', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('41', '21', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('42', '22', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('43', '24', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('44', '25', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('45', '26', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('46', '27', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('47', '28', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('48', '29', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('49', '30', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('50', '31', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('51', '32', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('52', '33', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('53', '34', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('54', '35', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('55', '36', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('56', '37', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('57', '38', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('58', '39', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('59', '40', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('60', '41', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('61', '42', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('62', '43', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('63', '44', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('64', '45', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('65', '46', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('66', '47', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('67', '48', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('68', '49', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('69', '50', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('70', '51', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('71', '52', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('72', '53', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('73', '54', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('74', '55', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('75', '56', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('76', '57', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('77', '58', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('78', '59', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('79', '60', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('80', '62', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('81', '63', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('82', '64', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('83', '65', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('84', '66', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('85', '67', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('86', '68', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('87', '69', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('88', '70', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('89', '71', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('90', '72', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('91', '73', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('92', '74', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('93', '75', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('94', '76', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('95', '77', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('96', '79', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('97', '80', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('98', '81', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('99', '82', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('100', '83', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('101', '84', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('102', '85', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('103', '86', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('104', '87', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('105', '88', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('106', '89', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('107', '90', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('108', '91', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('109', '92', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('110', '93', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('111', '94', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('112', '95', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('113', '96', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('114', '97', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('115', '100', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('116', '101', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('117', '102', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('118', '103', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('119', '104', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('120', '105', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('121', '106', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('122', '107', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('123', '108', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('124', '109', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('125', '110', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('126', '111', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('127', '112', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('128', '113', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('129', '114', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('130', '115', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('131', '116', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('132', '117', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('133', '118', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('134', '119', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('135', '120', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('136', '121', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('137', '122', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('138', '123', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('139', '124', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('140', '125', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('141', '126', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('142', '127', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('143', '128', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('144', '129', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('145', '130', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('146', '131', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('147', '132', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('148', '133', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('149', '134', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('150', '135', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('151', '136', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('152', '137', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('153', '138', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('154', '139', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('155', '140', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('156', '141', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('157', '142', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('158', '143', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('159', '144', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('160', '145', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('161', '146', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('162', '147', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('163', '148', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('164', '149', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('165', '150', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('166', '151', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('167', '152', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('168', '153', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('169', '154', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('170', '155', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('171', '156', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('172', '157', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('173', '158', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('174', '159', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('175', '160', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('176', '161', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('177', '162', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('178', '163', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('179', '164', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('180', '165', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('181', '166', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('182', '168', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('183', '169', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('184', '171', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('185', '173', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('186', '174', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('187', '175', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('188', '176', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('189', '177', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('190', '178', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('191', '179', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('192', '180', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('193', '181', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('194', '182', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('195', '183', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('196', '184', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('197', '185', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('198', '186', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('199', '187', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('200', '188', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('201', '189', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('202', '190', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('203', '191', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('204', '192', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('205', '193', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('206', '194', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('207', '195', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('208', '196', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('209', '197', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('210', '198', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('211', '199', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('212', '200', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('213', '201', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('214', '202', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('215', '203', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('216', '204', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('217', '205', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('218', '206', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('219', '207', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('220', '208', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('221', '209', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('222', '210', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('223', '211', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('224', '212', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('225', '213', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('226', '214', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('227', '215', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('228', '216', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('229', '217', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('230', '218', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('231', '219', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('232', '220', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('233', '221', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('234', '222', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('235', '223', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('236', '225', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('237', '226', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('238', '227', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('239', '229', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('240', '230', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('241', '231', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('242', '232', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('243', '233', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('244', '234', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('245', '235', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('246', '236', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('247', '237', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('248', '240', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('249', '241', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('250', '244', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('251', '245', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('252', '246', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('253', '165', 'C', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('254', '203', 'C', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('255', '223', 'C', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('256', '219', 'C', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('257', '228', 'C', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('258', '241', 'C', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('259', '245', 'C', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('260', '250', 'C', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('261', '266', 'C', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('262', '234', 'C', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('263', '177', 'C', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('264', '196', 'C', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('265', '166', 'C', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('266', '9', 'O', 'C');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('267', '5', 'O', 'C');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('268', '3', 'O', 'C');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('269', '2', 'O', 'C');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('270', '9', 'A', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('271', '10', 'A', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('272', '247', 'P', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('273', '11', 'A', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('274', '12', 'A', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('275', '13', 'A', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('276', '254', 'C', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('277', '248', 'P', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('278', '255', 'C', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('279', '249', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('280', '250', 'P', 'B');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('283', '258', 'C', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('282', '257', 'C', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('284', '259', 'C', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('285', '251', 'P', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('286', '252', 'P', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('287', '253', 'P', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('288', '260', 'C', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('289', '254', 'P', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('290', '255', 'P', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('291', '261', 'C', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('292', '256', 'P', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('294', '257', 'P', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('295', '263', 'C', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('297', '11', 'N', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('298', '9', 'N', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('299', '8', 'N', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('300', '6', 'N', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('301', '12', 'N', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('302', '10', 'N', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('303', '7', 'N', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('304', '5', 'N', 'D');
INSERT INTO ?:discussion (`thread_id`, `object_id`, `object_type`, `type`) VALUES ('305', '45', 'O', 'C');


INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я впервые увидел этот монитор в одном из компьютерных магазинов. Он действительно выделяется цветом и очень привлекает к себе внимание. Я смотрю на нем фильмы, играю в игры. Единственное, что я хотел бы изменить, это экран для обработки текстов (незначительная жалоба). Это очень хороший монитор и цена хорошая для 3D LCD.', '1', '1');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Монитор слишком светлый, и регулировка контрастности и яркости не помогает. Независимо от того, что настройка яркости и контрастности используется, все так или иначе слишком тусклое, серое или слишком светлое. Яркость и контрастность монитора, кажется, имеют одинаковую функцию регулировки. При изменении контрастности, кажется, на самом деле изменяется яркость и наоборот. Я, вероятно, верну его в ближайшее время, если мне никто не сможет правильно настроить яркость / контрастность.', '2', '1');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Просто идеальный!!!', '3', '2');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Мне не понравился.', '4', '2');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Очень красивые сапоги. Они самые лучшие.', '5', '3');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я приобрел Galaxy Tab в пятницу. Экран имеет очень широкий угол обзора, прежде чем приобрести Galaxy Tab, я смотрел Ipad2, и не нашел различия, кроме памяти.
\nЯ уверен, что Galaxy Tab лучше.', '8', '17');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Легкий, диагональ 8.9 самая оптимальная.
\nНедостатки: есть моменты, которые раздражают при перевороте, ориентация экрана менялась с задержкой, при переключении между экранами тоже есть случаи зависания.
\nБрал с расчетом на компактность и быстродействие.
\nSamsung Galaxy мой самый любимый.', '9', '17');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я очень доволен этим ЖК телевизором. Я искал и читал все о телевизорах с плоским экраном. Я так впечатлен качеством изображения и звука, даже при том, что в некоторых отзывах я читал что качество звука и объем не очень. В целом, преимуществами являются: ​встроенный динамик, яркий дисплей, реалистичные цвета, легкий. Определенно рекомендовал бы это своим друзьям.', '10', '18');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Наслаждаюсь этим телевизором. Цвета удивительны, глубина, баланс и все остальное просто на высшем уровне! Я могу подключить свой жесткий диск и смотреть видео мгновенно! Я до сих пор поражен ясностью. Есть возможность Blue-Ray. Хотя цена относительно высока, я могу сказать, что это удивительное произведение технологического мастерства.', '11', '19');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Приобрел домашний кинотеатр. Я немного опасался системы 5,1 Channel, но решили дать ему попытку. Звук хороший, хотя средний диапазон немного яснее. Система определенно не хватает низких частот, так что я в настоящее время ищу хороший сабвуфер. Высокие частоты кристально чистые, хотя объемное звучание. Я бы не рекомендовал его всем, но он определенно достаточно хорош в своем сегменте, хотя и не идеален.', '12', '20');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Отличное качество изображения ЖК-диспля на основе LED, с относительно глубокими уровнями для темных сцен, также хороший баланс белого. Она включает в себя встроенный Wi-Fi, 3D очки, и много других интересных функций. В целом, это довольно хороший телевизор, хотя картина в темных сценах иногда теряется под определенным углом.', '13', '21');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я искал простую и удобную в использовании видеокамеру. Когда я увидел T10 Full HD, она мне показалась действительно отличной видеокамерой! Если вы просто хотите снять видео, или планируют сделать полный видео проект - эта видеокамера станет вашим лучшим другом! В ней есть все необходимые функции, которые легко регулируется. Я не сталкивался с проблемами в использовании этой камеры. Определенно стоит своих денег!', '14', '22');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Хороший и надежный телефон является необходимым для человека, как я, вот почему я решил выбрать iPhone. Apple, является замечательной компанией, и идет всегда в ногу со временем, дальновидный и инновационный. IPhone прост в использовании и, безусловно, самый стильный телефон на рынке в настоящее время. Наслаждаюсь этим, хотя иногда испытываю проблемы с программным обеспечением и обслуживанием. Есть телефон буквально напичканы большим количеством функций, которые не используют. Я бы рекомендовал это в основном молодому поколению, а людям старшего поколения это не столь необходимо.', '15', '23');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я сначала долго думал что выбрать Nikon или Canon, но когда у меня появился шанс сравнить две модели 2 конкурирующих гигантов, я выбрал Nikon. Вы знаете, с ним чувствуешь себя хорошо. Цвета, матрица, интерфейс - превзошли все ожидания! Я уже сделал портфолио с его помощью. Просто прекрасный!', '16', '24');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я пользовался iPhone 5 и iPhone 5s каждый день в течение прошлого года, кажется, они похожи: те же загнутые края, габариты. Только изменилась кнопка Home, камера, вспышка, которая заставить вас осознать, что это не iPhone 5. Многие люди думают, что выпустив тот же дизайн, два раза-это плохо, и есть другие, которые понимают, что иногда нет необходимости перемен. Apple, возможно понимает, что конкуренция сильна, и она нуждается, чтобы оставаться актуальными.', '17', '25');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Аппарат отличный, не зависает, все удобно и просто.Те кто говорят что у него куча проблем и он такой сякой просто либо противники Apple, но лично у меня все без глюков и проблем.
\nМоя оценка твердая 5.', '18', '25');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Пользуюсь уже год и планшет в отличном состоянии до сих пор. Глючил bluetooth, иногда не хотел работать WIFI, не удалялись некоторые приложения и частенько зависали. Однако, должен заметить, служил он верой и правдой и все функции (чтение книг и учебников), просмотр фильмов, интернет и работа с файлами - выполнялись достойно.
\nПосле прошивки на официальную 4.0.4 не могу нарадоваться - все глюки будто рукой сняло - нормальная поддержка многоядерности - все стало летать как ракета.', '48', '235');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Отличный телефон! Действительно удобен и прост в пользовании. У меня был выбор между Galaxy SIII, Lumia 920, HTC J Butterfly, ну и Iphone. Я взяла Iphone, потому что в нем нет ничего лишнего и приложения не зависают. Даже если очень захотеть, то тормозить все равно не будет. Так же у него прекрасная камера, довольно резвый браузер.
\n
\nНедостатки: Зарядка в принципе извечная проблема со всеми новыми телефонами, но мне её вполне хватает.', '20', '23');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Не фотоаппарат, а конфетка просто. Не пожалела денег и купила его, он того стоит. Снимки получаются живыми и реалистичными. Со временем собираюсь приобрести новый объектив. В отличии от Canon, это просто лучшая фотокамера. Думала насчет Canon 550D, но потом поменяла свое решение, когда узнала о данной модели. Получаются отличные снимки в действии, портретные снимки. Быстро фокусируется! Единственно снимки на дальние расстояния меня не вдохновили, скорее всего это минус объектива. Но это просто мелочь, на них не стоит концентрировать свое внимание.
\nВсем советую приобрести этот фотоаппарат!', '21', '24');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я купил этот монитор еще в середине апреля. Прочитал много отзывов, большинство было отрицательных. Этот монитор является фантастическим. У него нет никаких проблем с цветом. Я купил дополнительно пару 3D очков Nvidia, так что я могу поделиться абсолютно потрясающими впечатлениями от этого монитора. Мало того, что экран как-будто выскакивает на тебя, но он также имеет большую глубину. У меня есть большая коллекция Blue Ray фильмов. С этим монитором я вижу детали, которые не видел прежде. Цвета яркие и Тона точны.
\nВсем советую!', '22', '238');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('У меня было 4 различных 3D монитора на протяжении многих лет, но этот монитор оказался лучшим. Что касается возможности 3D, изображение четкое, без искажений. Монитор также поддерживает высокий уровень яркости. Экран 27-дюймовый просто превосходный. Цвета, яркость и контрастность отличные. Этот монитор можно использовать, даже если вам не нужна функция 3D. Единственный недостаток, который я нашел монитор медленно пробуждается из спящего режима. В целом, я оцениваю монитор в 5 звезд.', '23', '238');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Монитор HP превысило мои самые смелые ожидания. Монитор очень яркий, цветопередача отличная. С точки зрения остроты это фантастика. Этот монитор очень легкий. Нет мертвых пикселей. Я рад, что приобрел его, и я рекомендую его друзьям. Я не могу себе представить человека, недовольного данным монитором.', '24', '239');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Монитор действительно является большим. Я представлял себе хороший монитор, но этот монитор превзошел мои ожидания. LED достаточно яркий.
\nИгры, фильмы выглядят очень хорошо и богато.', '25', '239');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Прекрасный компьютер. Покупался для домашнего пользования. Подключен к телевизору 42\". Компактный корпус, влезет куда угодно.', '26', '226');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Небольшой (вполне уместится на письменном столе), высокая пропускная способность видеокарты в текущем ценовом диапазоне, система восстановления ОС (активируется нажатием F9).
\nНедостаток: При первом запуске монитор не показывает картинку, нужно подождать несколько минут не выключая компьютер.', '27', '226');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Купил месяца полтора назад. Работает очень быстро и без сбоев, тихо. Оценка 4 так как сначала было не привычно пользоваться вертикальным приводом CD и DVD дисков, но потом это не вызвало неудобств. Так же отмечу из плюсов два порта USB на передней панели. Из минусов, что они за дверцей на которую надо нажать, чтобы до них добраться, но это для красоты:) Еще не с первого раза включается кнопка питания (просто надо посильней нажать), что для женщин может быть неудобно. Так же радует компактность блока.', '28', '229');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Очень мощный компьютер, высокая производительность и быстродействие. Отлично воспроизводит видео и игры без торможения.', '29', '229');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Дизайн в порядке не настолько впечатляющий. Графика интегрирована средствами ATI Radeon HD300, этот процессор предназначен для игр. Скорость работы отличная. Это процессор хорош.
\nДовольно дорогой, но стоит того, совместим с любым монитором.', '30', '230');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Системный блок является достаточно мощным для игр. Он также позволяет играть с DVD-дисков. Четко воспроизводит потоковое видео с веб-сайтов, таких как YouTube.', '31', '230');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Взял две штуки на работу в надежде поставить на них Убунту. Это оказалось неожиданно сложно в силу каких-то проблем с железом и BIOS. С горем пополам поставили - но работает убунту на нем очень плохо из-за проблем с поддержкой видео.
\n
\nЕдинственное достоинство внешний вид.
\nНедостатки:
\n- Слабое железо.
\n- Матрица по углам и цветам плохая.
\n- Один пиксель битый.
\n- Из колонок независимо от ОС и драйверов постоянно слышен назойливый противный фон.
\nКонкретно эту модель брать не советую, совсем она неудачная.', '32', '250');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Цена низкая, для офисной работы, тихий. Проблема с драйверами. На официальном сайте такой модели вообще не значится и драйверов под нее соответственно нет.
\nДля любителей повозиться с техникой на досуге', '33', '250');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Купил из за мощной видео карты!
\nПоложительные моменты: надежность, качественный звук, громкость, привлекательный дизайн, цвет, небольшой вес, габариты, естественная цветопередача, оптимальное соотношение цена/качество.', '34', '234');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Отличнейший мультимедийный ноутбук. Все, что нужно есть. Правда в супер игровые новинки не поиграешь из-за встроенной видеокарты. Заряд держит очень долго, стильный.
\nОтрицательные моменты: Слишком большой размер и вес', '35', '234');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('В пользовании меньше месяца. Хорошая машина для дома, кому требуется достаточная производительность и адекватная цена. Немного толстовата для современных мобильных ПК, зато есть хороший Salent режим, в котором ноутбук совершенно не слышно, вдобавок засыпает и просыпается очень быстро, ни каких лампочек в режиме сна не мигает (кроме зарядки, если она подключена).
\nПорадовало ПО, всё по делу. Даже есть разбивка жёсткого при первом включении.
\nЦветовые решения очень порадуют девушек.
\nЭкран вполне подойдёт для рабочего использования и интернет серфинга, фото на нём обрабатывать нельзя.
\nСтавлю 5, а минусы совершенно не меняют картины, если вы знаете что вы берёте и для чего.', '36', '231');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Пользовался больше года, вначале купил просто что бы можно было ходить на кухне, ноутбук справился со всем на \"Ура\".
\nАвтономное время работы совпало с заявленным, что тоже обрадовало.
\nВ общем, за свои деньги отработал на все 100%, да еще и с лихвой.', '37', '231');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Дизайн по мне отличный. Выглядит тонким, и реально не толстый, не тяжелый, время автономии приличное, ходил в библиотеку на день, батареи хватало, шнур не нужен.
\nЕсть подсветка, но она меня огорчает. Приходится включать фонарик или лампу. Сама клавиатура у меня неровная, она как небольшая волна, сразу не заметил, потом присмотрелся к отпечаткам на экране и уже поздно думаю менять. Опять же присмотрелся и увидел, как в углах неровно скреплены детали, вроде мелочь. За год стал скрипеть немного, в левой части вверху и внизу ощутимо. Видел у коллеги такой же и, сравнив, мы поняли, что системная особенность.', '38', '232');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Не думала, что у аппарата за такие деньги могут быть такие недостатки.
\nКачество экрана не удовлетворяет. Небольшие углы обзора, разрешение.
\nЕсть куча настроек, для меня абсолютно бесполезных. Греется довольно сильно. Качество корпуса оставляет желать лучшего. Местами скрипит, проминается под нажатием пальцев. Почему не сделали металл по всей поверхности, а не только там где кнопки, не понятно. Так бы и выглядел лучше и возможно не скрипел бы.
\nПро звук ничего говорить не буду. Лучше через штатные динамики его не слушать.
\nОт батареи работает часа 1.5, если смотреть видео. Посмотреть фильм полностью на одном заряде батареи не возможно.
\nНо с этим всем я бы мог смириться, если бы не кнопки. Они стали отваливаться уже через несколько месяцев эксплуатации. Возвращать их на место можно несколько раз, но, в конце концов, их хлипкие крепления ломаются, и кнопки перестают держаться на месте. Лучше бы были обычные кнопки, без подсветки, но которые надежно держаться и не отваливаются.
\nИ это отнюдь далеко не самая бюджетная модель в линейке.
\nНе рекомендую.', '39', '232');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Менее года назад приобрела данную модель ноутбука. При таком уровне далеко даже не средней цены, удивили те \"мелочи\", которые не предусмотрены при разработке:
\n- изоляция блока питания порвалась (несмотря на аккуратную эксплуатацию).
\n- очень маркий корпус (отпечатки пальцев везде. Можно использовать только в перчатках)
\n- материал, которые обрамляет клавиатуру весь потрескался)
\nВнутренности все более чем устраивают, хотя есть ряд ошибок, которые выдаются на систематической основе:
\n- сетевой адаптер плохо ловит сеть (хотя стоит драйвер последней версии).
\n- при закрытии крышки и переходе в спящий режим, через некоторое время сам перезагружается, не сохраняя последние версии доков.', '40', '233');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Единственный недостаток в работе - подсветка клавиатуры подсвечивает латинский алфавит,а кириллица за счёт контражура видна ещё хуже.
\nПоложительные моменты: качественный звук, громкость, привлекательный дизайн, цвет, небольшой вес, габариты, естественная цветопередача.', '41', '233');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Отличный планшет!!! Вот подарили на день рождения, пользуюсь уже 6 месяцев и ни как не нарадуюсь!!!Игры, Фильмы, Музыку качает отменно!Отличная графика, контрастные фотографии, всё видно прекрасно! Давно хотела себе именно ЭТОТ планшет, и мечтания сбылись!!!
\nСоветую ВСЕМ!', '42', '249');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Отличная вещь. Купила месяц назад и все свободное время провожу с ним. Если кто хочет приобрести,не сомневайтесь, никакие другие производители не сравнятся с iPad.', '43', '249');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('В своей ценовой категории это самый надежный и прочный продукт. Прекрасно ориентируется в пространстве. Сверхчувствительный сенсор, отличная картинка. Время работы наивысшее во всей линейке товаров.
\nК сожалению нет Flash, но это компенсируется специальной программой (правда она не лицензионная). Отсутствие разъёма USB компенсируется переходником.', '44', '248');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Графика, удобство использования, огромное количество приложений, защищенность. Относительный недостаток батарея, зависит от яркости подсветки и запущенных приложений, порой вылетает из некоторых приложений.
\nПрекрасная вещь! Очень рада, что отговорили брать galaxy tab. Не расстаюсь с ним, вся жизнь теперь в нем. Безумно удобен в учебе, удобно читать книги. Бесплатных приложений вполне хватает для работы и учебы.', '45', '248');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Яркий дисплей, недорогой, легкий, простой для хранения и чтения, расширяемой памяти через микро-SD. Есть настройки для доступа и управления домашним компьютером, через Интернет.
\nИдеальный размер - я могу держать его одной рукой.', '46', '236');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Приобрела Galaxy Tab 7 почти месяц назад, и я действительно впечатлена. E-mail, веб-браузер, карты, календарь, текстовые сообщения, так много функций. Так легко носить с собой по сравнению с IPAD.
\nОт всей души рекомендую его другим.', '47', '236');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Поскольку сравнивать особо не с чем, это мой первый планшет, тормозов не замечено. Перед покупкой внимательно рассматривал Sony и Apple. Результатом сравнения массы параметров стал Samsung.
\nИнтернет тормозит, но дома есть интернет через wifi, на который планшет автоматически переходит и все летает. Никаких неудобств с расположением динамиков и интерфейсов также нет, достаточно перевернуть экран. Время непрерывной работы около 10-12 часов. Если отключить сигналы, уведомления, gps и прочее в данный момент ненужное, то батарейки хватит надолго.
\nПокупкой доволен, рекомендую остальным.', '49', '235');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Очень дорогое устройство, с кривыми драйверами если пытаться работать на 5 Гц больше 3-4 часов, скорость падает, иногда теряет соединение, притом с родным роутером от ASUS N66U. Лучше посмотреть в сторону других более дешевых аналогов.', '50', '219');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Решил попробовать ASUS USB-N53. Для меня выбор оказался удачным на все 100%! Никаких проблем с сетью не испытываю. Интернет устраивает полностью. Смотрю сериалы на турбо фильме в максимальном качестве, не выключая BitTorrent - кэширует моментально. В игры не играю, поэтому для моих задач - хватает с достатком. Самое главное, что не надо читать кучу FAQ на форумах, как пофиксить тот, или иной баг. Купил, воткнул, работает!', '51', '219');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Устройство вызывает больше положительных моментов. Из минусов - неадекватно высокая цена. Ну, греется хорошо, хотя не так и критично. Просто единственное, не стоит его прятать в очень маленькое пространство, например - ящик стола.
\nИз плюсов: дизайн! Стильно впишется дома. Индикация не яркая, т.е. ночью не будет светильником. Но и в темноте не разберешь что за лампочка светится, все они близнецы. Легко настроил, хотя, если нужен только Wi-Fi то это явно расточительство, но если хотите получить большего, то откроете многое для себя! Функционал богатейший, а кому не хватает - ставьте альтернативные прошивки.
\nP.s. оценку снизил только из-за очень большой цены!!!', '52', '218');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Наверное продукцией Asus, пользоваться уже не буду. Была модель этого производителя раньше, проработала 2 года и такая же история, как с новым. Только не выходит в интернет, а Wi-Fi есть. Фирма солидная, но наверное не в этом сегменте оборудования или как попадешь.', '53', '218');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Эта вещь просто не работает. Заставила меня обновить прошивку, которая является бета-версией.
\nИзбегайте D-Link в целом и данного маршрутизатора в частности!', '54', '217');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я долгое время использовал продукцию D-Link. Я купил этот маршрутизатор и с 1 дня у меня появились проблемы, он постоянно зависает и требует перезагрузки 2-3 раза в день.', '55', '217');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я пробовал много камер безопасности на протяжении многих лет, и это является лучшей и одной из самых дешевых. Когда я впервые установил его, я был впечатлен качеством видео. Данная камера позволяет делать более резкие изображения.', '56', '220');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Камера позволяет делать только 15 FPS при любом разрешении. Мало того, она имеет низкую скорость захвата. Если человек не стоит на месте, все что вы увидите, будет как в тумане.', '57', '220');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Печатаю регулярно уже полгода, пока сменил один комплект картриджей и уже почувствовал разницу, так как тут за те же 3000 руб я купил комплект из четырех цветов. Функционал тоже выигрывает у лазерного принтера. Просто принтер,который стоит в дальнем углу и не требует никакого к себе внимания. При всём при том выдаёт прекрасные распечатки в цветном и ч/б исполнении. Из режима сна выходит за несколько секунд.
\nКартриджи подходят различных производителей,поэтому стоимость печати удалось снизить до весьма приемлемой.', '58', '223');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Классный дизайн для машины - зверя. Быстро и легко осуществляется замена чернил, очень удобный лоток для бумаги. Возможности сканера и ксерокса поражают. Все делает быстро и качественно, нареканий по качеству выходящей продукции никаких. По сравнению со многими конкурентами интерфейсы заметно быстрее работают, да и нет перегрева при постоянной загрузке. Стоящая покупка, если нужен действительно помощник \"все в одном\"! Стоит своих денег и достаточно быстро окупается.', '59', '223');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Этот принтер недорогой, и прекрасно работает! Печатает красивые фотографии. Я очень счастлива что приобрела его. \"Все-в-одном\" принтер, сканер и копировальный аппарат. Я использую его постоянно! Моя единственная жалоба, что при использовании других не чернил HP, он не показывает уровень чернил.
\nНо все же отличный продукт!', '60', '222');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('НР Photosmart Plus B210a отличный небольшой принтер все-в-одном. Он имеет множество функции, которые содержатся в более дорогих принтерах: сенсорный контроля, двойные лотки для бумаги и беспроводной связи.', '61', '222');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Сканером пользуюсь постоянно и печатаю достаточно много, около 7000-8000 листов в месяц. По моему это внушительная цифра, в инструкции написано до 10000. С объемами он легко справляется. Очень привлекательная в первую очередь цена, не ожидал что он так долго будет работать под нагрузкой. Был приятно удивлен.', '62', '224');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Купил это мфу по совету знакомого. Разобрался быстро, да и ПО в комплекте идущее - тоже более чем легко в освоении оказалось. Печатает очень быстро, экономит кучу времени.
\nРаботает он тихо, ничего нигде не шумит, корпус подогнан плотно.', '63', '224');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Не советую. Пока настроишь аппарат, пока им воспользуешься - времени пройдет кучу. Раньше мечтал все старые снимки отсканировать. Данное устройство было куплено в основном для этих целей. Но потратив пол часа на 7 фотографий и оценив сколько недель работы предстоит впереди - бросил данное занятие. Сейчас использую только для копирования документов.', '64', '221');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Удачная покупка! При такой низкой цене самого аппарата качество сканируемых фотографий и пленок превосходное. Для оцифровки домашнего архива (как бюджетный вариант) подходит идеально.
\nКонечно, для негативов хотелось бы получить лучший результат. Но тут очень много зависит от самой пленки, ее состояния.
\nС ПО у меня проблем не возникло, все работает, никаких сложностей нет. А то, что иногда медленно (негативы на большом разрешении), так это не критично.', '65', '221');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Простота установки. Работает на отметке 29-35 градусов, разогнанных до 3,8 ГГц. Действительно хорошие инвестиции. Много встроенной графики.
\nМинусов нет.', '66', '225');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Прочный и надежный на воздушном охлаждении. Система с i7-3770K Ivy Bridge 3,5 ГГц.
\nПрактически нет минусов, за исключением, цены.', '67', '225');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Процессор отличный, 6 ядер и 12 потоков, в тестах кодирования впечатляющие результаты, в 3dmark vantage при 4.5ghz(воздух) набирает 41300 очков! Для игр можно e8400 брать и гнать до 4ггц.
\nВообщем я о покупке не жалею.', '68', '227');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Купил себе эту \"игрушку\",очень доволен!
\nВо первых он решает сразу все мои задачи по максимуму. А это работы в программах типа 3DS MAx и прочих,хорошо жрущих ресурсы.', '69', '227');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Положительные моменты платформы в целом: трехканальная память дает 6 слотов, 6 гб. на 3 планках идеально подходит для 64-битной ОС.
\nЦена более чем адекватна!', '70', '237');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Решив перейти на i7, я купил этот процессор, так как на данный момент только он единственный из своей линейки обладает приемлемой ценой. Температура без нагрузки 51-53 в пассивном режиме, 47-48 в активном. При полной нагрузке температура приближается к 80 градусам.', '71', '237');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Интерфейс на основе браузера является Glitchy. Иногда он подключается сразу. Иногда мне приходится подключать и отключать его несколько раз. Явно не готов к продаже.', '72', '49');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Намного лучше, чем Garmin-х. Объекты не появляются на карте.
\nЕсли вы едите сверх лимита отображает скорость в красном цвете.
\nОпределяет маршруты с задержкой.', '73', '49');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Довольно прост в использовании. Обнаружение маршрута занимает много времени! Также у меня были проблемы с получением обновления карт.
\nВ целом, это хороший GPS-навигатор и я с ним еще ни разу не заблудился.', '74', '48');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Фантастическая штука, очень быстрая.
\nСтоит купить. Мне нравится, как он меняет маршрут. Цена для него маленькая.', '75', '48');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Мне не понравился GPS-навигатор, по следующим причинам:
\n- Время задержки связи со спутниками. Иногда он не может найти их вообще.
\n- Часто не правильно показывает, где я нахожусь.
\n- При поиске самых близких мест, он показывает мне самые отдаленные.
\n- Неправильно рассчитывает расстояние.
\n- Крепление не держится на лобовом стекле.
\n
\nЯ обновил карты и ничего не изменилось. Я скорей всего его верну.', '76', '52');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я не могу поверить, что так долго обходился без GPS!! Я использую его, чтобы  определить маршрут. Этот GPS прекрасно работает, и это так удобно. Единственный недостаток его трудно выключить, я должен несколько раз коснуться экрана, прежде чем он выключится.', '77', '52');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я очень рад что купил этот навигатор. Я использую его в поездках и не имели никаких проблем с ним. Программное обеспечение, работает отлично. Я даже скачал несколько пользовательских POI, и они работали здорово. Автоматическое масштабирование и уменьшение не так плохо, как некоторые говорят. Номера телефонов и вся информация о каждом POI есть, вы просто должны нажать на информационную вкладку, чтобы его увидеть.', '78', '51');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('3450 имеет хорошую цену, более быстрый процессор, сенсорный экран, отличную графику.
\nЭто качественный GPS-навигатор.
\nСПАСИБО!', '79', '51');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Прежде чем купить, я прочел множество отзывов. Мое первое впечатление, что он работает хорошо.
\nЯ получил дополнительный кабель и он подключается к моему телефону. Радио прекрасно работает. Это моя любимая функция.
\nСистема GPS работает быстро.
\nЯ установил камеры заднего вида к данному устройству и она работает очень хорошо. Я был впечатлен качеством изображения.
\nВсем советую приобрести.', '80', '79');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Этот навигатор определенно стоит того, чтобы его купить. Он выглядит великолепно. Даже кнопки соответствуют интерьеру моей машины. Существует очень мало бликов на солнце. Есть процесс интеграции с Ipod, легко изменять список воспроизведения. Он также отображает обложки альбомов, которые я люблю. Он также имеет тюнер и встроенный HD радио тюнер.', '81', '79');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Очень довольна приобретением. Стерео достаточно громкое. Единственный недостаток, устройство не имеет BlueTooth.', '83', '56');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я установил это устройство в мою машину Ford. Для установки я просто подключил соответствующие провода моей машины.
\nПосле установки устройство загрузило все мои песни с USB-накопителя, также проигрывает песни с диска. Звук просто отличный. Мне также нравится, что я могу сделать дисплей более темным.
\nТакже у меня есть жалоба. Как установить часы и цвета дисплея я очень долго искал в интернете, потому что я не мог найти данные настройки в инструкции.', '84', '56');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я купила эту аудиосистему как подарок другу, потому что это то, что он попросил! Это стерео именно то, что он хотел, и он цена меня полностью устраивала! Он проигрывает музыку с компакт дисков! Так же есть тюнер. Товар полностью соответствует описанию в магазине!', '85', '61');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я купил Pioneer DEH-1300MP, потому что другой мой стерео сломался. Мне понравилась данная модель в связи с относительно низкой ценой, маркой Pioneer, достаточной мощностью, а также тем фактом, что у него есть все возможности, которые меня интересуют.
\nПосле установки я включил его и не мог поверить, насколько хорошо он звучит по сравнению с моим старым. Я могу проигрывать на этом MP3-плеер все компакт-диски.', '86', '61');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Это простая в управлении автомагнитола. Огромный плюс возможность обновления программы. Bluetooth звонки и интеграция с iPhone безупречна. Потоковое BT аудио звучит не так хорошо, что делает качество заметно ниже.
\nВключенные функции DSP дают огромный выбор звуковых вариантов. Любимые особенности: слот SD позади лицевой панели. Регулировка уровня позволяет поддерживать несколько уровней громкости через различные источники.
\nОчень рекомендую приобрести.', '87', '58');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Просто супер. Сбалансированный ровный звук. Является редким устройством, который имеет все необходимое, идеально подходит для меня. Я так рад, что приобрел его.', '88', '58');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я заказал эту  автомагнитолу для моего маленького грузовика. Устройство установилась быстро. Функция HD-радио является фантастическим. Bluetooth работает очень хорошо, и есть много дополнительных кабелей. Легкое подключение к Android и качество звука хорошее. Настройка не такая уж сложная, просто не торопитесь и следуйте инструкциям. Есть пульт дистанционного управления.
\nЯ рекомендую это устройство друзьям!', '89', '59');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я была настроена скептически к этому устройству, но после его приобретения была очень рада. Это очень мощное устройство. Легко настраивается и имеет много цветов на выбор для освещения. Недостатком является то, что я не могу добавлять радиостанции.', '90', '59');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Эта автомагнитола, то что я хотела. Есть Bluetooth подключение довольно не навязчивое. Эквалайзер легко изменяется, меню довольно легкое. Дисплей сенсорный яркий с голубым освещением.', '91', '62');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Автомагнитола просто супер. Я могу добавлять радиостанции. Качество Bluetooth на высшем уровне, соединяется очень легко. Единственное что мне не понравилось это стерео.', '92', '62');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Купил эти колонки и ни разу не разочаровался в них. Они имеют отличное звучание. Они рассчитаны на питание от усилителя Clarion. Качество динамиков высшего уровня. Если вы ищете качественный динамик с качественным звуком, который не будет очень дорого, то это то что вам нужно.', '93', '68');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я купил два комплекта для себя и для друга. У меня не было никаких проблем с установкой, и они оказались не большими. Единственное, качество звука хотелось чтобы было лучше.', '94', '68');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я купила из взамен моих старых колонок. Они звучат гораздо лучше. Я положила перегородки позади колонок, чтобы защитить их, и улучшить звук. Единственное, что мне не нравиться, то что Pioneer изменил металлический материал на пластиковый, поэтому оценка 3.', '95', '69');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Звук отличный. Высокочастотные динамики, довольно хороши. Они в основном являются мини сабвуферами.
\nВ целом я счастлива и безусловно не раскаиваюсь в покупке.', '96', '69');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Динамики огромные, качество отличное. Громкоговорители звучат великолепно. Они поражают низкими нотами!
\nБольшое спасибо!', '97', '70');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Эти колонки смешные, но очень хорошего качества. Они имеют невероятные, минимальные уровни сабвуфера. Я буквально пугаюсь, когда их слушаю!
\nОпределенно рекомендовал бы их.', '98', '70');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Эти динамики отлично работают, я установил их под задним сиденьем и они звучат потрясающе. Я искали динамики, которые бы играли громко. Эти колонки не разочаровали. Я могу слушать весь день музыку без зарядки аккумулятора.', '99', '67');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я был очень впечатлен исполнением этих динамиков. 8-дюймовые конусы действительно предоставляют много баса. Первоначально я ожидал, что эти динамики могут преждевременно выйти из строя, но они работают до сих пор!
\nНедостаток: Эти негабаритные громкоговорители требуют большой мощности, для достижения максимальной производительности.', '100', '67');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я приобрел этот сабвуфер давно. Он не гремит, бас чистый, свежий, без искажений. Я использую 4 канала 1600W усилителя с АПЛ. Также у него высокая мощность генератора.
\nПросто отличный сабвуфер!', '101', '72');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('У меня было много сабвуферов от Kicker до Alpine. Купив этот сабвуфер я был поражен насколько хорошо он передает каждую ноту. Я не был удивлен, узнав, что этот сабвуфер был оценен, как лучший, по качеству и звуку.
\nПоверьте мне ... Вы не будете разочарованы.', '102', '72');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я полюбила этот сабвуфер, как только вынула его из коробки. Он очень громкий. Kenwood производит качественный товар. Хорошая мощность с низким уровнем искажений. Если вы ищете удивительную систему бюджетного варианта, я рекомендую их к вам.
\nНадеюсь этот отзыв кому-нибудь поможет.', '103', '71');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Очень доволен этим сабвуфером, работает отлично, лучшая цена. Я уже думаю приобрести еще один.
\nЯ рекомендую всем, кому нужно отличное звучание! ', '104', '71');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я купил сабвуфер, чтобы установить в машину. Он просто замечателен!!! Я установил его в герметичный корпус, запускал на 1 Ом и он отлично работает. Сабвуфер отлично звучит при низких частотах. Он являются чемпионом.', '105', '73');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Это лучший сабвуфер. Он может производить звуки и вибрации как ни один другой сабвуфер. У него великолепное звучание. Даже несмотря на то, что его частотная характеристика не совсем сбалансирована, звучит он все равно здорово. Очень чистый низкий бас.
\nСпасибо за замечательный продукт!', '106', '73');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Действительно качественный звук! Очень доволен, идеально вписался в машину. Устраивает все. Конечно сложновато управление, но есть инструкция. Быстро установил. Для своей цены – просто шик, а не усилитель!', '107', '75');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я сравнивала несколько усилителей Pioneer и обнаружила, что это устройство более универсальное. В инструкции все подробно описано. Поиск места для установки было самым трудным.', '108', '75');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я купил этот усилитель взамен 1200 Вт Kenwood усилителю. Он очень качественный, имеет дистанционный плагин усиления. Я могу изменять коэффициент усиления для разных песен. Этот усилитель творит чудеса. Устанавливается очень легко и имеет синий светодиод.', '109', '76');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Весит усилитель около 300 фунтов. Он прекрасно вписывается и здорово работает! Есть регулировка усиления. Никаких проблем с усилителем у меня пока не возникало.
\nЯ рекомендую приобрести этот усилитель.', '110', '76');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я купила этот усилитель за его небольшие габариты и низкие тепловыделения. Она прекрасно вписывается, так что становится полностью невидимой, но по-прежнему доступны в случае необходимости.
\nЦена понравилась, доставка быстрая.', '111', '74');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Этот усилитель имеет небольшой вес с чистым звуком. Это мой первый сабвуферный усилитель! На большой мощности звук не такой качественный, как на среднем и низком уровне, но для обычного любителя вполне ничего!', '112', '74');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('У меня нет никаких проблем с ним. Очень рад, что купил.
\nЯ использовал Bluetooth для подключения к моему телефону. Также использую USB-накопитель, чтобы проигрывать музыку, которую я скачал. Для переключения с USB-накопителя к радио и обратно требуется около 30 секунд. HD радио звучит здорово на любом канале.
\nТаким образом, я сделал очень хорошее приобретение и получил массу удовольствий от его использования.', '113', '78');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Интерфейс очень хороший, быстрый, простой в использовании во время вождения. Переход от одной песни к другой происходит очень быстро.
\nЗвук отличный. Только проблема с настройкой видео во время вождения.', '114', '78');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Это устройство удивительное: яркий экран, возможность изменения изображения. Bluetooth сопряжение выполняется быстро и легко. Я могу делать небольшие изменения эквалайзера во время вождения. HD радио просто ошеломляет. Есть цифровое телевидение, радиостанции HD!', '115', '77');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Люблю это устройство. Включает в себя все хорошие функции. Аудио звук и видео отлично воспроизводятся. Есть возможность управления через телефон. Звук отличный! Большое количество опций!', '116', '77');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Cobra серии работает очень хорошо. При этом было 1-2 ложных тревоги за последние 2 месяца использования, в связи с нахождением рядом с автоматическими дверями на предприятие. Тем не менее я очень впечатлен этим радаром-детектором. Кроме того, у радара-детектора есть кнопка отключения звука. Металлический кронштейн очень прочно держит радар-детектор.', '117', '83');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Данная модель более чувствительная и заранее оповещает водителя. Он также обладает функциями обнаружения для области или местности. Хорошо продумана инструкция и пользовательские кнопки. Я испытала это устройство во многих городах. Независимо от того, где бы я не находилась он всегда меня предупреждал о наличие камеры на дороге.', '118', '83');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я очень рад что приобрел Cobra, он спас меня дважды от получения штрафа. Ложные сигналы были, но очень редко. Мне нравиться функция компас и IntelliMute. Размер немного больше, что у других радаров-детекторов. Спиральный шнур идеально подходит для моего автомобиля.
\nВ целом я очень доволен Cobra.', '119', '82');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я купила этот детектор и очень довольна. Я живу в сельской местности и радар мне просто необходим при поездках в город. Следует отметить работает он очень хорошо. Несколько ложных тревог и случайных помех, но режим город прекрасно работает для ограничения ложных тревог. Это мой первый радар-детектор.', '120', '82');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Высший радар. Пользуюсь почти год. Никаких претензий. Ложных срабатываний почти нет.', '121', '80');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Это самый сложный высокочувствительный радар. Радар-детектор имеет много функций, чтобы снизить количество ложных предупреждений. Мне нравится функция IntelliMute. Экран видим при ярком дневном свете, есть функция затемнения. Цвета значков можно изменять. Сенсорный экран является бесценным.', '122', '84');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Плюсами данного устройства являются, то что он цифровой радар с сенсорным экраном с легко читаемым дисплеем. Имеет степень защиты 360. Также плюсом является голосовые оповещения. Он содержит так много возможностей. Дополнительными особенностями я считаю, являются GPS Locator, предупреждение о низком заряде батареи и индикатор скорости.', '123', '84');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Работа магазина на высшем уровне, отправили в первый же будний день после заказа. Товаром доволен. Полная комплектация.\nРекомендую.', '124', '141');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Регулярно делаю покупки в этом магазине, доволен всеми товарами.
\nУдобный способ заказа, быстрая доставка, доступные цены, богатый ассортимент товаров.', '125', '26');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Удобный каталог.
\nОперативная реакция на заказ и оповещение о статусе заказа. Цены приемлемые.', '126', '26');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Являюсь активным пользователем данного интернет-магазина.
\nИнтернет-магазин очень порадовал ассортиментом, объективными ценами, оперативным выполнением заказов, быстрой доставкой. Очень удобный сайт, дружественный интерфейс, есть различные акции.', '127', '26');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Всегда относился немного предвзято к интернет-магазинам и не особо им доверял, но обратившись в этот интернет-магазин мое мнение изменилось. Очень понравился ассортимент товаров. Доволен сервисом и оперативностью магазина.', '128', '26');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Осталась очень довольна качеством обслуживания интернет-магазина, стоимостью и условиями доставки. Заказывала неоднократно и никогда не было нареканий. Это мой самый любимый интернет-магазин.', '129', '26');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Я люблю это сайт. Здесь можно найти все. Узнала я о нем уже довольно давно. Частенько заказываю себе оттуда что-нибудь. Этот сайт делает скидки на многие товары, что определенно радует! В общем, я очень рада, что \"открыла\" эту площадку для себя, так как она позволяет экономить много денег.', '130', '26');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Из всех просмотренных сайтов с планшетами, здесь навигация по сайту наиболее удобная + описание есть, картинки хорошие – знаешь, чего ожидать. Ну и оформила я заказ за пару минут.', '131', '253');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Очень понравился магазин, покупаю там с прошлого года. И друзьям рекомендовала.', '132', '265');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Просто огромный выбор спортивных товаров. То есть практически для любого вида спорта. Найдется ВСЕ! Я не могу отнести себя, и свою семью, к профессиональным спортсменам. Мы просто любим активный отдых, часто выезжаем на природу (и в ближний лесок, и в дальние горы). Закупаем здесь и одежду, и снаряжение.', '133', '254');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Большой выбор одежды на любой вкус. Модели красивые, современные, размерный ряд весь. Выбирай – не хочу.', '134', '255');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Часто покупаю одежду в этом магазине для себя и детей. Всегда остаемся довольными и качеством и дизайном изделий. Спасибо!', '135', '255');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Это единственный магазин, где я покупаю книги. Преимущество - широкий ассортимент литературы, по любой тематике. Всегда найдётся нужная книга. К тому же, можно прочитать отзывы, критику, описание, посмотреть оценки и иллюстрации к товару. Это очень удобно и экономит время. Больше всего радует система скидок и акций и очень низкие цены за доставку. Очень радует возможность самовывоза. Можно придти в любой день и забрать свой заказ.', '136', '256');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Очень люблю этот магазин! В последнее время покупаю книги только здесь. Многочисленные иллюстрации позволяют познакомиться с товаром и выбрать то, что действительно нужно, поэтому никогда не бываю разочарована покупкой. Очень радует система скидок: дождавшись акции, дорогое издание можно приобрести по вполне доступной цене. Служба доставки работает великолепно! Спасибо! Благодаря вам, я сформировала прекрасную библиотеку.', '137', '256');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Получил первый заказ. Может пока рано делать какие-то выводы, но впечатления остались приятные. Во-первых, это жёлтый надёжный (во всех отношениях) конверт, ну, и во-вторых, конечно же, сам диск - новый. Спасибо!!!', '138', '257');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Магазин прекрасный, не было ещё такого случая, чтобы я не нашла здесь необходимого.
\nОГРОМНОЕ СПАСИБО!', '139', '260');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Отличный интернет магазин, широкий ассортимент. Заказ доставили быстро. Спасибо.', '140', '266');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Доброго времени суток! Сегодня получила свой заказ, все доставили быстро!', '141', '267');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Вчера получила заказ, очень довольна! Очень хорошее качество. Спасибо Вам!', '142', '268');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Все пришло! Большое спасибо, всем доволен.', '143', '269');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Приставка очень классная! Контроллер с экраном это очень удобная вещь! Удобно играть (игры специально сделаны для планшета, куча фишек), удобно пользоваться интернетом (пишу с него же), браузер очень продуманный, удобно общаться в сети и делать покупки в специальном магазине!
\nО магазине - он тоже очень удобный и простой! Быстро покупать, есть акции где можно купить интересные игрушки за не большую цену! Купила её из-за \"Бетмена\", очень классно сделана, играть одно удовольствие! Да и цены, как многие пишут, не выше чем у конкурентов!', '144', '279');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Новая консоль от Nintendo, теперь с графикой уровня Xbox 360 и PS3. Для игр в компании отлично подойдут игры вроде Nintendo Land, New Super Mario Bros. U и Rabbids Land. Связка ТВ плюс экран геймпада - это действительно весело и интересно.', '145', '279');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('В общем, покупкой доволен. Всё оказалось так, как я и ожидал. Если у вас есть деньги и страстное желание прикоснуться к некстгену, нет довольно мощного ПК, где можно поиграть в большинство игр из магазина Sony по гораздо более низким ценам, и просто стать одним из первых обладателей приставки - можете смело покупать. Всем остальным можно не спешить и дождаться большего количества эксклюзивов, выход которых намечен ближе к осени.', '146', '280');
INSERT INTO ?:discussion_messages (`message`, `post_id`, `thread_id`) VALUES ('Отличная консоль. Пока только радует. Вообще поколение только разгоняется, и какие-либо существенные недостатки указать сложно.', '147', '280');


INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('1', '1', 'Иван Митрофанов', '1406114992', '3', '192.168.0.2', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('2', '1', 'Елена Круглова', '1406156189', '0', '192.168.0.2', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('3', '2', 'Татьяна Вершкова', '1406179040', '1', '192.168.0.2', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('4', '2', 'Олег Диментьев', '1406210565', '0', '192.168.0.2', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('5', '3', 'Екатерина Воротникова', '1406274497', '3', '192.168.0.2', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('8', '17', 'Александр Краснов', '1406299810', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('9', '17', 'Антон Лисицин', '1406343819', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('10', '18', 'Александр Дмитриев', '1406400805', '0', '10.7.7.93', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('11', '19', 'Михаил Ворошилов', '1406428012', '0', '10.7.7.93', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('12', '20', 'Елена Бушуева', '1406507980', '0', '10.7.7.93', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('13', '21', 'Ольга Дмитриева', '1406526232', '0', '10.7.7.93', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('14', '22', 'Николай Волин', '1406579316', '0', '10.7.7.93', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('15', '23', 'Светлана Иванова', '1406628187', '0', '10.7.7.93', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('20', '23', 'Нина Цифаркина', '1406655145', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('16', '24', 'Елена Николаева', '1406703330', '0', '10.7.7.93', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('21', '24', 'Виктория Краснова', '1406760950', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('17', '25', 'Олег Фуражкин', '1406776470', '0', '10.7.7.93', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('18', '25', 'Ольга Сердцева', '1406853359', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('125', '26', 'Маслов Алексей', '1406873762', '7', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('126', '26', 'Михайлова Елена', '1406938955', '6', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('127', '26', 'Родионова Ксения', '1406968714', '2', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('128', '26', 'Петров Денис', '1407020268', '3', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('129', '26', 'Иванова Мария', '1407057779', '5', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('130', '26', 'Петрова Анна', '1407084981', '4', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('74', '48', 'Илья Ефимов', '1407149566', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('75', '48', 'Иван Митрофанов', '1407181524', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('72', '49', 'Ольга Сердцева', '1407210830', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('73', '49', 'Виктория Краснова', '1407278680', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('78', '51', 'Олег Фуражкин', '1407328478', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('79', '51', 'Максим Иванов', '1407341177', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('76', '52', 'Ольга Сердцева', '1407396365', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('77', '52', 'Леонид Ефимов', '1407448500', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('83', '56', 'Елена Николаева', '1407493299', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('84', '56', 'Иван Колышев', '1407524878', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('87', '58', 'Николай Ворошилов', '1407569835', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('88', '58', 'Юрий Кондрашов', '1407630893', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('89', '59', 'Александр Дмитриев', '1407653480', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('90', '59', 'Раиса Малышева', '1407693475', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('85', '61', 'Нина Гаврилова', '1407751490', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('86', '61', 'Антон Михайлов', '1407797507', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('91', '62', 'Татьяна Вершкова', '1407840070', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('92', '62', 'Иван Митрофанов', '1407872619', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('99', '67', 'Петр Горбунов', '1407896777', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('100', '67', 'Иван Колышев', '1407941592', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('93', '68', 'Александр Краснов', '1408019320', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('94', '68', 'Олег Фуражкин', '1408023159', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('95', '69', 'Нина Цифаркина', '1408069150', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('96', '69', 'Ольга Сердцева', '1408121201', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('97', '70', 'Александр Дмитриев', '1408179078', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('98', '70', 'Алексей Моисеев', '1408213947', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('103', '71', 'Светлана Виноградова', '1408267258', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('104', '71', 'Леонид Ефимов', '1408286380', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('101', '72', 'Илья Ефимов', '1408328796', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('102', '72', 'Виктор Вединов', '1408405832', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('105', '73', 'Иван Колышев', '1408424949', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('106', '73', 'Виктория Краснова', '1408495183', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('111', '74', 'Раиса Малышева', '1408499523', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('112', '74', 'Виктория Краснова', '1408581264', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('107', '75', 'Виктор Вединов', '1408584075', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('108', '75', 'Нина Гаврилова', '1408654456', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('109', '76', 'Леонид Ефимов', '1408700711', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('110', '76', 'Ольга Сердцева', '1408744292', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('115', '77', 'Николай Волин', '1408764885', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('116', '77', 'Светлана Иванова', '1408822252', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('113', '78', 'Олег Фуражкин', '1408877007', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('114', '78', 'Елена Бушуева', '1408920567', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('80', '79', 'Виктор Вединов', '1408966031', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('81', '79', 'Нина Гаврилова', '1408991819', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('121', '80', 'Александр Краснов', '1409037863', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('119', '82', 'Олег Диментьев', '1409070939', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('120', '82', 'Екатерина Воротникова', '1409121360', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('117', '83', 'Александр Дмитриев', '1409178008', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('118', '83', 'Елена Бушуева', '1409214328', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('122', '84', 'Антон Лисицин', '1409264258', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('123', '84', 'Александр Краснов', '1409315924', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('124', '141', 'Николай Волин', '1409330869', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('54', '217', 'Светлана Виноградова', '1409372652', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('55', '217', 'Леонид Ефимов', '1409418174', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('52', '218', 'Светлана Виноградова', '1409483571', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('53', '218', 'Илья Ефимов', '1409508452', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('50', '219', 'Раиса Малышева', '1409543886', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('51', '219', 'Виктор Вединов', '1409601536', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('56', '220', 'Иван Колышев', '1409622953', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('57', '220', 'Елена Николаева', '1409704008', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('64', '221', 'Иван Колышев', '1409737479', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('65', '221', 'Светлана Виноградова', '1409775196', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('60', '222', 'Елена Круглова', '1409797519', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('61', '222', 'Иван Митрофанов', '1409845984', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('58', '223', 'Олег Фуражкин', '1409898082', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('59', '223', 'Татьяна Вершкова', '1409964803', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('62', '224', 'Иван Кудашов', '1410005921', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('63', '224', 'Илья Ефимов', '1410014032', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('66', '225', 'Светлана Виноградова', '1410078344', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('67', '225', 'Нина Гаврилова', '1410131206', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('26', '226', 'Раиса Малышева', '1410138806', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('27', '226', 'Виктор Вединов', '1410223004', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('68', '227', 'Илья Ефимов', '1410266115', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('69', '227', 'Татьяна Гнедова', '1410300056', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('28', '229', 'Илья Ефимов', '1410324426', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('29', '229', 'Нина Гаврилова', '1410379746', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('30', '230', 'Елена Иванова', '1410427646', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('31', '230', 'Татьяна Гнедова', '1410475403', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('36', '231', 'Антон Михайлов', '1410496630', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('37', '231', 'Юрий Кондрашов', '1410542310', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('38', '232', 'Николай Ворошилов', '1410593986', '7', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('39', '232', 'Татьяна Вершкова', '1410639697', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('40', '233', 'Елена Круглова', '1410697269', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('41', '233', 'Олег Диментьев', '1410703945', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('34', '234', 'Михаил Новиков', '1410774585', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('35', '234', 'Александр Дмитриев', '1410796988', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('48', '235', 'Иван Панов', '1410860191', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('49', '235', 'Ольга Дмитриева', '1410879504', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('46', '236', 'Антон Михайлов', '1410957294', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('47', '236', 'Елена Бушуева', '1410972925', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('70', '237', 'Елена Николаева', '1411027249', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('71', '237', 'Олег Фуражкин', '1411062234', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('22', '238', 'Иван Колышев', '1411108362', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('23', '238', 'Леонид Ефимов', '1411171560', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('24', '239', 'Светлана Виноградова', '1411175490', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('25', '239', 'Светлана Виноградова', '1411223785', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('44', '248', 'Нина Цифаркина', '1411302040', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('45', '248', 'Виктория Краснова', '1411332142', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('42', '249', 'Нина Круглов', '1411389967', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('43', '249', 'Валентина Андреева', '1411400609', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('32', '250', 'Алексей Моисеев', '1411461376', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('33', '250', 'Олег Крупицин', '1411501920', '0', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('131', '253', 'Михайлова Елена', '1411502919', '1', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('133', '254', 'Родникова Мария', '1411504521', '1', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('134', '255', 'Ефимова Надежда', '1411508482', '1', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('135', '255', 'Григорьева Ольга', '1411511220', '1', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('136', '256', 'Родионова Ксения', '1411513620', '1', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('137', '256', 'Аня Крупнова', '1411516021', '1', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('138', '257', 'Маслов Алексей', '1411520252', '1', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('139', '260', 'Елена Горбунова', '1411523412', '1', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('132', '265', 'Смирнова Екатерина', '1411524321', '1', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('140', '266', 'Анна Петрова', '1411526412', '4', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('141', '267', 'Мария Иванова', '1411528952', '5', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('142', '268', 'Ольга Григорьева', '1411531662', '6', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('143', '269', 'Николай Ворошилов', '1411533252', '7', '127.0.0.1', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('144', '279', 'Михайлова Елена', '1412340449', '1', '10.7.7.139', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('145', '279', 'Волина Ольга', '1412340540', '1', '10.7.7.139', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('146', '280', 'Петров Сергей', '1412340786', '1', '10.7.7.139', 'A');
INSERT INTO ?:discussion_posts (`post_id`, `thread_id`, `name`, `timestamp`, `user_id`, `ip_address`, `status`) VALUES ('147', '280', 'Устимова Анна', '1412340878', '1', '10.7.7.139', 'A');


INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '1', '1');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('2', '2', '1');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '3', '2');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('2', '4', '2');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '5', '3');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '8', '17');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '9', '17');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '10', '18');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '11', '19');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('3', '12', '20');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '13', '21');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '14', '22');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '15', '23');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '16', '24');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('3', '17', '25');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '18', '25');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('3', '20', '23');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '21', '24');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '22', '238');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '23', '238');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '24', '239');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('3', '25', '239');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '26', '226');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('3', '27', '226');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '28', '229');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '29', '229');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('3', '30', '230');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '31', '230');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('2', '32', '250');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('1', '33', '250');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '34', '234');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '35', '234');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '36', '231');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '37', '231');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '38', '232');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('2', '39', '232');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('2', '40', '233');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '41', '233');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '42', '249');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '43', '249');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('3', '44', '248');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '45', '248');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '46', '236');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '47', '236');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '48', '235');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '49', '235');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('2', '50', '219');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '51', '219');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '52', '218');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('2', '53', '218');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('2', '54', '217');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('3', '55', '217');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '56', '220');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('2', '57', '220');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '58', '223');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '59', '223');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '60', '222');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '61', '222');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '62', '224');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '63', '224');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('3', '64', '221');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '65', '221');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '66', '225');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '67', '225');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '68', '227');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('3', '69', '227');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '70', '237');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '71', '237');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('3', '72', '49');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('2', '73', '49');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '74', '48');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '75', '48');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('1', '76', '52');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '77', '52');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '78', '51');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '79', '51');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '80', '79');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('3', '81', '79');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '83', '56');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('3', '84', '56');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '85', '61');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '86', '61');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '87', '58');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '88', '58');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '89', '59');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '90', '59');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '91', '62');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('3', '92', '62');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '93', '68');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '94', '68');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('3', '95', '69');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '96', '69');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '97', '70');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '98', '70');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '99', '67');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('3', '100', '67');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '101', '72');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '102', '72');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '103', '71');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '104', '71');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '105', '73');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '106', '73');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '107', '75');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '108', '75');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '109', '76');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '110', '76');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '111', '74');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '112', '74');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '113', '78');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '114', '78');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '115', '77');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '116', '77');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '117', '83');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '118', '83');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '119', '82');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '120', '82');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '121', '80');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '122', '84');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '123', '84');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '124', '141');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '125', '26');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '126', '26');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '127', '26');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '128', '26');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '129', '26');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '130', '26');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '131', '253');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '132', '265');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '133', '254');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '134', '255');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '135', '255');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '136', '256');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '137', '256');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '138', '257');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '139', '260');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('0', '140', '266');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('0', '141', '267');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('0', '142', '268');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('0', '143', '269');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('5', '144', '279');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '145', '279');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '146', '280');
INSERT INTO ?:discussion_rating (`rating_value`, `post_id`, `thread_id`) VALUES ('4', '147', '280');
