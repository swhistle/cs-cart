REPLACE INTO ?:page_descriptions (page_id, lang_code, page, description, meta_keywords, meta_description, page_title) VALUES ('40', 'en', 'Poll of the week', '', '', '', '');
