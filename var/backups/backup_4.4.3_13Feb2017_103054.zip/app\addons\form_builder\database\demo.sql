REPLACE INTO ?:pages (page_id, parent_id, id_path, status, page_type, position, timestamp, new_window) VALUES ('30', '0', '30', 'A', 'F', '0', '1208808000', '0');

REPLACE INTO ?:form_options (`element_id`, `page_id`, `parent_id`, `element_type`, `value`, `position`, `required`, `status`) VALUES ('1', '30', '0', 'I', '', '3', 'Y', 'A');
REPLACE INTO ?:form_options (`element_id`, `page_id`, `parent_id`, `element_type`, `value`, `position`, `required`, `status`) VALUES ('2', '30', '0', 'Y', '', '1', 'Y', 'A');
REPLACE INTO ?:form_options (`element_id`, `page_id`, `parent_id`, `element_type`, `value`, `position`, `required`, `status`) VALUES ('3', '30', '0', 'T', '', '20', 'Y', 'A');
REPLACE INTO ?:form_options (`element_id`, `page_id`, `parent_id`, `element_type`, `value`, `position`, `required`, `status`) VALUES ('4', '30', '0', 'L', '', '0', 'N', 'A');
REPLACE INTO ?:form_options (`element_id`, `page_id`, `parent_id`, `element_type`, `value`, `position`, `required`, `status`) VALUES ('5', '30', '0', 'J', 'no-reply@example.com', '0', 'N', 'A');
REPLACE INTO ?:form_options (`element_id`, `page_id`, `parent_id`, `element_type`, `value`, `position`, `required`, `status`) VALUES ('6', '30', '0', 'U', 'N', '0', 'N', 'A');
REPLACE INTO ?:form_options (`element_id`, `page_id`, `parent_id`, `element_type`, `value`, `position`, `required`, `status`) VALUES ('7', '30', '0', 'I', 'N', '4', 'Y', 'A');
REPLACE INTO ?:form_options (`element_id`, `page_id`, `parent_id`, `element_type`, `value`, `position`, `required`, `status`) VALUES ('8', '30', '0', 'E', '7', '0', 'N', 'A');
REPLACE INTO ?:form_options (`element_id`, `page_id`, `parent_id`, `element_type`, `value`, `position`, `required`, `status`) VALUES ('9', '30', '0', 'K', '', '0', 'N', 'A');
