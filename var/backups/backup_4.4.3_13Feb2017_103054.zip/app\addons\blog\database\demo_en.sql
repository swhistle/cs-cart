REPLACE INTO ?:page_descriptions (page_id, page, description, lang_code) VALUES('7', 'Blog', '', 'en');

REPLACE INTO ?:page_descriptions (page_id, page, description, lang_code) VALUES('40', "Bikes for cool guys! We've got genuine Evolve bikes!", '<p><a href=\"index.php?dispatch=categories.view&amp;category_id=208\" target=\"_blank\"><img src=\"images/companies/1/news/bike2.jpg?1411558174165\" alt=\"\"></a></p>', 'en');

REPLACE INTO ?:page_descriptions (page_id, page, description, lang_code) VALUES('41', 'For those who love sound quality we have awesome Pioneer speakers!', '<p>
\n	<a href=\"index.php?dispatch=categories.view&amp;category_id=186\" target=\"_blank\"><img src=\"images/companies/1/news/pieoneer.jpg?1411558144750\" alt=\"\"></a></p>', 'en');
REPLACE INTO ?:page_descriptions (page_id, page, description, lang_code) VALUES('42', 'Afraid of zombies? Preparing for apocalypse?', '<p>
\n	<a href=\"index.php?dispatch=products.view&amp;product_id=116\" target=\"_blank\"><img src=\"images/companies/1/news/legend.jpg?1411558069817\" alt=\"\"></a></p>', 'en');
REPLACE INTO ?:page_descriptions (page_id, page, description, lang_code) VALUES('43', 'True American classic! Drifter cruisers.', '<p>
\n	<a href=\"index.php?dispatch=categories.view&amp;category_id=210\" target=\"_blank\"><img src=\"images/companies/1/news/bike.jpg?1411557959395\" alt=\"\"></a></p>', 'en');
REPLACE INTO ?:page_descriptions (page_id, page, description, lang_code) VALUES('44', 'We got the best tracks of legendary B.B.King.', '<p>
\n	<a href=\"index.php?dispatch=products.view&amp;product_id=199\" target=\"_blank\"><img src=\"images/companies/1/news/king.jpg?1411557839939\" alt=\"\"></a></p>', 'en');
REPLACE INTO ?:page_descriptions (page_id, page, description, lang_code) VALUES('45', 'Looking for a keypad Nokia phone and can\'t find one? We still have them!', '<p>
\n	<a href=\"index.php?dispatch=categories.view&amp;category_id=238\" target=\"_blank\"><img src=\"images/companies/1/news/nokia.jpg?1411558110201\" alt=\"\"></a></p>', 'en');
REPLACE INTO ?:page_descriptions (page_id, page, description, lang_code) VALUES('46', 'Only in our store! Famous American WeatherMaster tents!', '<p>
\n	<a href=\"index.php?dispatch=products.view&amp;product_id=236\" target=\"_blank\"><img src=\"images/companies/1/news/palatka.jpg?1411557721029\" alt=\"\"></a></p>', 'en');
REPLACE INTO ?:page_descriptions (page_id, page, description, lang_code) VALUES('47', 'New arrivals of Nintendo Wii games!', '<p>
\n	<a href=\"index.php?dispatch=categories.view&amp;category_id=246\" target=\"_blank\"><img src=\"images/companies/1/news/wii.jpg?1411557599553\" alt=\"\"></a></p>', 'en');