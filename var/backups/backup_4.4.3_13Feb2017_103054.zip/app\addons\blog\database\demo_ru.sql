REPLACE INTO ?:page_descriptions (page_id, page, description, lang_code) VALUES('7', 'Блог', '', 'ru');

REPLACE INTO ?:page_descriptions (page_id, page, description, lang_code) VALUES('40', 'Байки для реально крепких парней! Мы завезли настоящие Evolve!', '<p>
\n	<a href=\"index.php?dispatch=categories.view&category_id=208\" target=\"_blank\"><img src=\"images/companies/1/news/bike2.jpg?1411558174165\" alt=\"\"></a>
\n</p>
\n<p>
\n	Evolve гипер-эффективный, для активных людей. Характер подвески поглащает все неровности, очень точная управляемость на всех скоростях
\n</p>', 'ru');
REPLACE INTO ?:page_descriptions (page_id, page, description, lang_code) VALUES('41', 'Для любителей качественного звука, мы завезли отличные динамики Pioneer!', '<p>
\n	<a href=\"index.php?dispatch=categories.view&category_id=186\" target=\"_blank\"><img src=\"images/companies/1/news/pieoneer.jpg?1411558144750\" alt=\"\"></a>
\n</p>
\n<p>
\n	Динамики Pioneer улучшат звук в вашем автомобиле. Новые динамики с новой концепцией дизайна, сверхвысокочастотные более точно воспроизводят звук.
\n</p>', 'ru');
REPLACE INTO ?:page_descriptions (page_id, page, description, lang_code) VALUES('42', 'Опасаетесь зомби и уже копите запасы на случай армагедона?', '<p>
\n	<a href=\"index.php?dispatch=products.view&product_id=116\" target=\"_blank\"><img src=\"images/companies/1/news/legend.jpg?1411558069817\" alt=\"\"></a>
\n</p>
\n <p>
\n	Американский художественный фильм с Уилл Смитом, является экранизацией романа Ричарда Мэтисона. Знаменитый фильм, который стоит посмотреть всем.
\n</p>', 'ru');
REPLACE INTO ?:page_descriptions (page_id, page, description, lang_code) VALUES('43', 'Мы завезли настоящую американскую классику! Круизеры Drifter.', '<p>
\n	<a href=\"index.php?dispatch=categories.view&category_id=210\" target=\"_blank\"><img src=\"images/companies/1/news/bike.jpg?1411557959395\" alt=\"\"></a>
\n</p>
\n<p>
\n	Новые крузеры Drifter очень удобные, просты в использовании. Стильный дизайн крузера Drifter не оставит равнодушной ни одну девушку.
\n</p>', 'ru');
REPLACE INTO ?:page_descriptions (page_id, page, description, lang_code) VALUES('44', 'Приехали лучшие произведения легендарного блюзмена B.B.King.', '<p>
\n	<a href=\"index.php?dispatch=products.view&product_id=199\" target=\"_blank\"><img src=\"images/companies/1/news/king.jpg?1411557839939\" alt=\"\"></a>
\n</p>
\n<p>
\n	Лучшие произведения культового блюзмена B.B.King. Достаточно редкий диск с выдающимися произведениями.
\n</p>', 'ru');
REPLACE INTO ?:page_descriptions (page_id, page, description, lang_code) VALUES('45', 'Ищете кнопочную Nokia и нигде не можете найти? А у нас они еще есть!', '<p>
\n	<a href=\"index.php?dispatch=categories.view&category_id=238\" target=\"_blank\"><img src=\"images/companies/1/news/nokia.jpg?1411558110201\" alt=\"\"></a>
\n<p>
\n	Классические кнопочные телефоны Nokia - надежные телефоны.\r\nУ нас представлены всевозможные модели кнопочных телефонов Nokia с разнообразной цветовой гаммой.
\n</p>', 'ru');
REPLACE INTO ?:page_descriptions (page_id, page, description, lang_code) VALUES('46', '​Только в нашем магазине! Знаменитые американские палатки WeatherMaster!', '<p>
\n	<a href=\"index.php?dispatch=products.view&amp;product_id=236\" target=\"_blank\"><img src=\"images/companies/1/news/palatka.jpg?1411557721029\" alt=\"\"></a>
\n</p>
\n<p>
\n	Для любителей активного отдыха. Палатки WeatherMaster легкие, удобные, воздухопроницаемые, предназначенные для комфортного проживания. Всесезонные палатки сделаны из специального материала, который защитит вас от дождя.
\n</p>', 'ru');
REPLACE INTO ?:page_descriptions (page_id, page, description, lang_code) VALUES('47', 'Мы завезли новые игры для Nintendo Wii!', '<p>
\n	<a href=\"index.php?dispatch=categories.view&category_id=246\" target=\"_blank\"><img src=\"images/companies/1/news/wii.jpg?1411557599553\" alt=\"\"></a>
\n</p>
\n<p>
\n	Долгожданные игры для Nintendo. Новые игры придутся по вкусу всем, в них вы окунетесь в захватывающий мир с полюбившими героями.\r\nУспейте приобрести!!!
\n</p>', 'ru');