REPLACE INTO ?:form_descriptions (`object_id`, `description`, `lang_code`) VALUES ('1', 'Full name', 'en');
REPLACE INTO ?:form_descriptions (`object_id`, `description`, `lang_code`) VALUES ('2', 'Email', 'en');
REPLACE INTO ?:form_descriptions (`object_id`, `description`, `lang_code`) VALUES ('3', 'Body', 'en');
REPLACE INTO ?:form_descriptions (`object_id`, `description`, `lang_code`) VALUES ('4', 'Thank you for contacting us. We''ll answer you at first opportunity.', 'en');
REPLACE INTO ?:form_descriptions (`object_id`, `description`, `lang_code`) VALUES ('7', 'Subject', 'en');
REPLACE INTO ?:form_descriptions (`object_id`, `description`, `lang_code`) VALUES ('9', '', 'en');