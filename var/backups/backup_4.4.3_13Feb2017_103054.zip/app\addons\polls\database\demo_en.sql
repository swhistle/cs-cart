REPLACE INTO ?:poll_descriptions (`object_id`, `page_id`, `lang_code`, `type`, `description`) VALUES ('40', '40', 'en', 'H', '');
REPLACE INTO ?:poll_descriptions (`object_id`, `page_id`, `lang_code`, `type`, `description`) VALUES ('40', '40', 'en', 'F', '');
REPLACE INTO ?:poll_descriptions (`object_id`, `page_id`, `lang_code`, `type`, `description`) VALUES ('40', '40', 'en', 'R', '');
REPLACE INTO ?:poll_descriptions (`object_id`, `page_id`, `lang_code`, `type`, `description`) VALUES ('1', '40', 'en', 'I', 'How often do you buy DVDs?');
REPLACE INTO ?:poll_descriptions (`object_id`, `page_id`, `lang_code`, `type`, `description`) VALUES ('2', '40', 'en', 'I', 'Once per week.');
REPLACE INTO ?:poll_descriptions (`object_id`, `page_id`, `lang_code`, `type`, `description`) VALUES ('3', '40', 'en', 'I', 'Every day.');
REPLACE INTO ?:poll_descriptions (`object_id`, `page_id`, `lang_code`, `type`, `description`) VALUES ('4', '40', 'en', 'I', 'Will buy my first right now!');
REPLACE INTO ?:poll_descriptions (`object_id`, `page_id`, `lang_code`, `type`, `description`) VALUES ('5', '40', 'en', 'I', 'Never, I prefer cinema.');
REPLACE INTO ?:poll_descriptions (`object_id`, `page_id`, `lang_code`, `type`, `description`) VALUES ('6', '40', 'en', 'I', 'Suggest your answer:');