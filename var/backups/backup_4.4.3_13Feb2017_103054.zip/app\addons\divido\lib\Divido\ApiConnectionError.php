<?php

class Divido_ApiConnectionError extends Divido_Error
{
}
