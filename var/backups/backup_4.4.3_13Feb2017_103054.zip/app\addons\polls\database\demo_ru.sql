REPLACE INTO ?:poll_descriptions (`object_id`, `page_id`, `lang_code`, `type`, `description`) VALUES ('40', '40', 'ru', 'H', '');
REPLACE INTO ?:poll_descriptions (`object_id`, `page_id`, `lang_code`, `type`, `description`) VALUES ('40', '40', 'ru', 'F', '');
REPLACE INTO ?:poll_descriptions (`object_id`, `page_id`, `lang_code`, `type`, `description`) VALUES ('40', '40', 'ru', 'R', '');
REPLACE INTO ?:poll_descriptions (`object_id`, `page_id`, `lang_code`, `type`, `description`) VALUES ('1', '40', 'ru', 'I', 'Как часто вы покупаете DVD?');
REPLACE INTO ?:poll_descriptions (`object_id`, `page_id`, `lang_code`, `type`, `description`) VALUES ('2', '40', 'ru', 'I', 'Раз в неделю.');
REPLACE INTO ?:poll_descriptions (`object_id`, `page_id`, `lang_code`, `type`, `description`) VALUES ('3', '40', 'ru', 'I', 'Каждый день.');
REPLACE INTO ?:poll_descriptions (`object_id`, `page_id`, `lang_code`, `type`, `description`) VALUES ('4', '40', 'ru', 'I', 'Сейчас куплю первый диск!');
REPLACE INTO ?:poll_descriptions (`object_id`, `page_id`, `lang_code`, `type`, `description`) VALUES ('5', '40', 'ru', 'I', 'Не покупаю, предпочитаю кинотеатр.');
REPLACE INTO ?:poll_descriptions (`object_id`, `page_id`, `lang_code`, `type`, `description`) VALUES ('6', '40', 'ru', 'I', 'Предложите свой ответ:');