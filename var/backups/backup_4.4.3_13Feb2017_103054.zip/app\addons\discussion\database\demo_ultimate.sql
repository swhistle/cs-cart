UPDATE ?:discussion SET company_id = 1;
