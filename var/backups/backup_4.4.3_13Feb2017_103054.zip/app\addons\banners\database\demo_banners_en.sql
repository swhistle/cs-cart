REPLACE INTO ?:banner_descriptions (`banner_id`, `banner`, `url`, `description`, `lang_code`) VALUES(7, 'Gift certificate', 'gift_certificates.add', '', 'en');
REPLACE INTO ?:banner_descriptions (`banner_id`, `banner`, `url`, `description`, `lang_code`) VALUES(8, 'Holiday gift guide', 'gift_certificates.add', '', 'en');

REPLACE INTO ?:banner_images (`banner_image_id`, `banner_id`, `lang_code`) VALUES(16, 7, 'en');
REPLACE INTO ?:banner_images (`banner_image_id`, `banner_id`, `lang_code`) VALUES(18, 8, 'en');

REPLACE INTO ?:banner_descriptions (`banner_id`, `banner`, `url`, `description`, `lang_code`) VALUES(16, 'Final sale', 'index.php?dispatch=products.final_sale', '', 'en');
REPLACE INTO ?:banner_descriptions (`banner_id`, `banner`, `url`, `description`, `lang_code`) VALUES(17, 'X-Box', 'index.php?dispatch=products.view&product_id=248', '', 'en');
REPLACE INTO ?:banner_descriptions (`banner_id`, `banner`, `url`, `description`, `lang_code`) VALUES(18, 'Bonus points', 'index.php?dispatch=pages.view&page_id=23', '', 'en');
REPLACE INTO ?:banner_descriptions (`banner_id`, `banner`, `url`, `description`, `lang_code`) VALUES(19, 'Gift certificates', 'index.php?dispatch=pages.view&page_id=19', '', 'en');
REPLACE INTO ?:banner_descriptions (`banner_id`, `banner`, `url`, `description`, `lang_code`) VALUES(6, 'Free shipping', 'index.php?dispatch=pages.view&page_id=22', '', 'en');
REPLACE INTO ?:banner_descriptions (`banner_id`, `banner`, `url`, `description`, `lang_code`) VALUES(9, 'Discount if select pickup', 'index.php?dispatch=pages.view&page_id=20', '', 'en');

REPLACE INTO ?:banner_images (`banner_image_id`, `banner_id`, `lang_code`) VALUES(35, 16, 'en');
REPLACE INTO ?:banner_images (`banner_image_id`, `banner_id`, `lang_code`) VALUES(36, 17, 'en');
REPLACE INTO ?:banner_images (`banner_image_id`, `banner_id`, `lang_code`) VALUES(37, 18, 'en');
REPLACE INTO ?:banner_images (`banner_image_id`, `banner_id`, `lang_code`) VALUES(38, 19, 'en');
REPLACE INTO ?:banner_images (`banner_image_id`, `banner_id`, `lang_code`) VALUES(39, 6, 'en');
REPLACE INTO ?:banner_images (`banner_image_id`, `banner_id`, `lang_code`) VALUES(40, 9, 'en');
