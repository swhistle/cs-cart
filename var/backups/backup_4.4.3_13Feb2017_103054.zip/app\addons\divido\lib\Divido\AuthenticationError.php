<?php

class Divido_AuthenticationError extends Divido_Error
{
}
